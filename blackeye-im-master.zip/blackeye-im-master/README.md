


<p align="left">
<a href="#"><img title="Made in INDIA" src="https://img.shields.io/badge/MADE%20IN-INDIA-green?colorA=%23ff9933&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="#"><img title="blackeye-im" src="https://i.imgur.com/5N5Kdjw.png"></a>
</p>
<p align="center">
<a href="https://github.com/Git-Ankitraj"><img title="Author" src="https://img.shields.io/badge/Author-Git--Ankitraj-red.svg?style=for-the-badge&logo=github"></a>
<a href="#"><img title="Open Source" src="https://img.shields.io/badge/Open%20Source-%E2%9D%A4-green?style=for-the-badge"></a>
</p>
<p align="center">
<a href="#"><img title="Version" src="https://img.shields.io/badge/Version-2.0-green.svg?style=flat-square"></a>
<a href="#"><img title="Language" src="https://badges.frapsoft.com/bash/v1/bash.png?v=103"></a>
<a href="https://github.com/Git-Ankitraj/followers"><img title="Followers" src="https://img.shields.io/github/followers/The-Burning?color=blue&style=flat-square"></a>
<a href="https://github.com/Git-Ankitraj/blackeye-im/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Git-Ankitraj/blackeye-im?color=red&style=flat-square"></a>
<a href="https://github.com/Git-Ankitraj/blackeye-im/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Git-Ankitraj/blackeye-im?color=red&style=flat-square"></a>
<a href="https://github.com/Git-Ankitraj/blackeye-im/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Git-Ankitraj/blackeye-im?label=Watchers&color=blue&style=flat-square"></a>
</p>












# BLACKEYE v2.0
<ul type='disc'> <li>Termux Support
<li> New latest Webpages

</ul>
 <a href="#"><img title="blackeye-im" width= "20%" src="https://i.imgur.com/5N5Kdjw.png"></a>
 
# blackeye-im
Ultimate phishing tool with ngrok and serveo.

# Installation (for linux):
```
git clone https://github.com/Git-Ankitraj/blackeye-im.git
cd blackeye-im
chmod +x ./setup.sh
./setup.sh
```
Usage:

```./blackeye.sh```
<p><a href="https://i.imgur.com/irdzUjd.png"><img title="blackeye-im" src="https://i.imgur.com/irdzUjd.png"></a>
</p>

# Android (termux and equivalents).
```
git clone https://github.com/Git-Ankitraj/blackeye-im.git
cd blackeye-im
chmod +x ./tmxsp.sh
```
Usage:

```./tmxsp.sh```
<p><a href="#"><img title="blackeye-im" src="https://i.imgur.com/YuAb55M.jpg"></a>
</p>
Note: Made for Educational Purposes,use it with mutual consent of the victim.
<p><a href="https://i.imgur.com/TJFmaGq.png"><img title="blackeye-im" src="https://i.imgur.com/TJFmaGq.png"></a>
</p>

 

-----------------------------------------------------------------------------------------------------------------------------

## BLACKEYE v2.0
### UPDATES :Added new websites and Upgraded the phishing pages to make it look more authentic

-----------------------------------------------------------------------------------------------------------------------------


## Legal disclaimer:

Usage of BlackEye for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program. Only use for educational purposes.


## Contact:
<p align="center">
    <a href="https://www.instagram.com/ankitraj_707/">
    <img alt="Instagram" src="https://img.shields.io/badge/Instagram%20-%23000000.svg?&style=for-the-badge&logo=Instagram&logoColor=white"/></a>
    <a href="https://twitter.com/Ankitraj7079">
    <img alt="Twitter" src="https://img.shields.io/badge/Twitter%20-%231DA1F2.svg?&style=for-the-badge&logo=Twitter&logoColor=white"</a>
    <a href="https://discord.com/channels/@me/798505744843538432">
    <img alt="Discord" src="https://img.shields.io/badge/Discord%20-%237289DA.svg?&style=for-the-badge&logo=discord&logoColor=white"/></a>
</p>
