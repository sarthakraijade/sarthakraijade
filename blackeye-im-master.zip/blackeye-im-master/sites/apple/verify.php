<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">



















    


 











<html >

    <head>

        <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
        <meta http-equiv="pics-label" content='(pics-1.1 "http://www.icra.org/ratingsv02.html" l gen true for "http://www.apple.com" r (cz 1 lz 1 nz 1 oz 1 vz 1) "http://www.rsac.org/ratingsv01.html" l gen true for "http://www.apple.com" r (n 0 s 0 v 0 l 0))'/>
        <meta name="Author" content="Apple Inc."/>
        <meta name="viewport" content="width=1024"/>
        <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7, IE=9" />

        <title>Apple - My Apple ID</title>

        <meta name="Category" content="" />
        <meta name="Description" content="" />

        <noscript>
            <meta http-equiv="Refresh" content="0;URL=/checkBrowserSettings"/>
        </noscript>

        <link rel="SHORTCUT ICON" href="/images/global/favicon.ico"/>

        <link rel="stylesheet" type="text/css" media="screen" href="https://appleid.cdn-apple.com/iforgot/staticresources/cssj/N1237674960/global.css" />


        
        

        <script type="text/javascript" src="https://appleid.cdn-apple.com/iforgot/staticresources/jsj/N1999511705/global.js" ></script>


        
        

        
        
        

        <script>
            $(document).ready(function() {
                if(!areCookiesEnabled()){
                    window.location = '/checkBrowserSettings';
                }
                addFieldToCaptureClientInfo('main_content');
            });
        </script>

    </head>

    <body id="vetting">
    
        
            
                







<script type="text/javascript">
    var searchSection = 'global';
    var searchCountry = 'us';
</script>
<style>
    #globalheader {
        /*
                    left:-15px;
         */
        /*override navigation.css */
        width: auto;
        -khtml-border-radius: 0px;
        -ms-border-radius: 0px;
        -o-border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        border-radius: 0px;
        -khtml-box-shadow: none;
        -ms-box-shadow: none;
        -o-box-shadow: none;
        -moz-box-shadow: none;
        -webkit-box-shadow: none;
        box-shadow: none;
    }

    iframe {
        width: 100%;
    }
</style>


<link rel="stylesheet" href="https://www.apple.com/ac/globalheader/1.0/styles/globalheader.css" type="text/css"/>








    
    

    

    

    

    

    

    

    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
        
    









    

    

    

    

    
    
    

    

    

    

    

    

    

    
    
    
    
    
    
    
    
    
    
    
        
    


<script type="text/javascript"></script>
<nav id="globalheader" class="globalheader" role="navigation" aria-label="Global Navigation" data-hires="false"
     data-analytics-region="global nav" lang="en-US">
    <div id="gh-content" class="gh-content">
        <ul class="gh-menu">
            <li id="gh-menu-icon-toggle" class="gh-menu-icon gh-menu-icon-toggle">
                <button id="gh-svg-icons" class="gh-svg-wrapper"></button>
                <span class="gh-text-replace">Menu</span></li>
            <li id="gh-menu-icon-home" class="gh-menu-icon gh-menu-icon-home"><a href="/"><span class="gh-text-replace">Apple</span></a>
            </li>
        </ul>
        <!--/gh-menu-->
        <div class="gh-nav">
            <div class="gh-nav-view">
                <ul class="gh-nav-list">

                    <li class="gh-tab gh-tab-apple"><a class="gh-tab-link"
                                                       href="http://www.apple.com/"><span
                            class="gh-tab-inner"><span class="gh-text-replace">Apple</span></span></a></li>
                    <li class="gh-tab gh-tab-store">


                        
                                

                        
                            
                            
                            
                            
                                <a class="gh-tab-link" href="http://store.apple.com/"><span
                                        class="gh-tab-inner"><span class="gh-text-replace">Store</span></span></a>
                            
                        
                    </li>
                    <li class="gh-tab gh-tab-mac">
                        
                            
                            
                                <a class="gh-tab-link" href="http://www.apple.com/mac/"><span
                                        class="gh-tab-inner"><span class="gh-text-replace">Mac</span></span></a>
                            
                        
                    </li>
                    <li class="gh-tab gh-tab-iphone">
                        
                            
                            
                                <a class="gh-tab-link" href="http://www.apple.com/iphone/"><span
                                        class="gh-tab-inner"><span class="gh-text-replace">iPhone</span></span></a>
                            
                        </li>
                   
                        <li class="gh-tab gh-tab-watch">
                            
                                
                                
                                    <a class="gh-tab-link" href="http://www.apple.com/watch/"><span
                                        class="gh-tab-inner"><span class="gh-text-replace">Watch</span></span></a>
                                
                        </li>
                    
                      <li class="gh-tab gh-tab-ipad">
                        
                            
                            
                                <a class="gh-tab-link" href="http://www.apple.com/ipad/"><span
                                        class="gh-tab-inner"><span class="gh-text-replace">iPad</span></span></a>
                            
                        </li>
                    <li class="gh-tab gh-tab-ipod">
                        
                            
                            
                                <a class="gh-tab-link" href="http://www.apple.com/ipod/"><span
                                        class="gh-tab-inner"><span class="gh-text-replace">iPod</span></span></a>
                            
                        
                    </li>
                    <li class="gh-tab gh-tab-itunes">
                        
                            
                            
                                <a class="gh-tab-link" href="http://www.apple.com/itunes/"><span
                                        class="gh-tab-inner"><span class="gh-text-replace">iTunes</span></span></a>
                            
                        
                    </li>
                    <li class="gh-tab gh-tab-support">
                        
                            
                            
                                <a class="gh-tab-link" href="http://www.apple.com/support/"><span
                                        class="gh-tab-inner"><span class="gh-text-replace">Support</span></span></a>
                            
                        
                    </li>
                    <li id="gh-tab-search" class="gh-tab gh-tab-search">
                        <div id="gh-search" class="gh-search" role="search">
                            <form action="/search/" method="post" class="gh-search-form" id="gh-search-form"
                                  data-search-recommended-results='{"url":"https://www.apple.com/global/nav/scripts/shortcuts.php","requestName":"recommendedResults","queryName":"q","dataType":"xml"}'
                                  data-search-suggested-searches='{"url":"https://www.apple.com/search/instant/getSuggestions","requestName":"suggestedSearches","queryName":"query","queryParams":{"model":"marcom_en_US","locale":"en_US"},"dataType":"json"}'>
                                <div class="gh-search-input-wrapper">
                                    <label for="gh-search-input" class="gh-text-replace">Search apple.com</label>
                                    <input type="text" name="q" id="gh-search-input" class="gh-search-input"
                                           placeholder="Search apple.com"/>
                                </div>
                                <button disabled="disabled" type="submit" id="gh-search-submit"
                                        class="gh-search-submit gh-search-magnify"><span class="gh-text-replace">Search apple.com</span>
                                </button>
                                <button disabled="disabled" type="reset" id="gh-search-reset" class="gh-search-reset">
                                    <span class="gh-text-replace">Reset</span></button>
                            </form>
                        </div>
                        <a class="gh-search-magnify" href="/search/"><span
                                class="gh-text-replace">Search apple.com</span></a>
                    </li>
                </ul>
            </div>
        </div>
        <!--/gh-nav-->
    </div>
</nav>




<script src="https://www.apple.com/ac/globalheader/1.0/scripts/globalheader.js" type="text/javascript"
        charset="utf-8"></script>

<input type="hidden" id="urlLanguageInsert" value="/"/>


            
            
        

        
            <div id="editContainerBody" class="myappleid reset steps step6" >
        
        


            









<div id="productheader">

    <a href="https://appleid.apple.com?localang=en_US">
        
            
            
        
        <h2><img src="https://appleid.cdn-apple.com/iforgot/staticresources/img/cb3005648865/images/global/title/myappleid_title_en_US.png" style="height: 35px;" alt="My Apple ID" /></h2>
    </a>

</div>

            <div id="main">

                <div id="content" class="content">

                    <div class="grid2colc wrap">

                        <div class="column first">
                            <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">





    
    
        <h2>
            Verify your account
        </h2>
        <h4>
            <p class="intro">
                Sign in with your Apple ID to confirm you are the original owner.
            </p>
        </h4>
    


                        </div>

                        <div class="column last main" id="main_content">
                            <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">








<img src="https://appleid.cdn-apple.com/iforgot/staticresources/img/cb2164569458/images/global/myappleid_check_20091125.png" height="31" alt="check" width="32" />

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">






<h2>Verification Completed</h2>
<p class="intro">
    Your Apple ID has been verified.
</p>









<p>
    
        
            
        
        
    
    <a class="more" href="https://appleid.apple.com">

    
        
        
        
            Return to My Apple ID
        
    
    </a>
</p>

 </div>

                    </div>

                </div>

            </div>

        </div>


        






<div id="globalfooter">

    <style> iframe { display: none; } </style>



    <div id="breadory">
        <ol id="breadcrumbs">
            <li class="home"><a href="http://www.apple.com" dir="ltr">Home</a></li>
            <li><a href='https://appleid.apple.com?localang=en_US'>My Apple ID</a>
            </li>
            
                
                
                    <li><a href="/password">Reset your password</a></li>
                
            
        </ol>
    </div>
    <script>
        if (document.getElementById('globalheader') != null) {
            if (document.getElementById('sp-searchtext') != null) {
                document.getElementById('sp-searchtext').removeAttribute("class");
            }
            document.getElementById('globalheader').className = "outside";
        }
        if (document.getElementById('iTuneApp') != null) {
            document.getElementById('iTuneApp').removeAttribute("class");
        }
    </script>

    










<div class="gf-sosumi">
    
    <p>Copyright &copy; 2014 Apple Inc. All rights reserved.</p>
    <ul class="piped">
        <li><a class="first" href="http://www.apple.com/legal/terms/site.html">Terms of Use</a></li>
        <li><a href="http://www.apple.com/legal/privacy">Privacy Policy</a></li>
        <li style="float:right">
            <a class="choose" title="Choose your country or region" href="https://appleid.apple.com/choose-your-country/">
                <p style="display:inline;margin-right:-5px; padding-right:0px;">Choose your country or region</p>

                
                    
                    
                

                <img src="https://appleid.cdn-apple.com/iforgot/staticresources/img/cb3129794114/images/global/flags/flag_US.png" height="22" style="float:right;" alt="United States" width="22" />
            </a>
        </li>
    </ul>
</div>

</div>

    </body>
</html>